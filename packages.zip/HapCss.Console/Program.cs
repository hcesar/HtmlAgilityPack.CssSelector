﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HapCss
{
    class Program
    {
        static void Main(string[] args)
        {
            HtmlNode node;
            IList<HtmlAgilityPack.HtmlNode> nodes;
            //var tokens = Tokenizer.GetTokens(".class #id1 div.class2").ToList();
            var doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load("test2.html");


            nodes = doc.QuerySelectorAll("p:not(.cls)");
            var classes = nodes.SelectMany(i => i.GetClassList());
            nodes = doc.QuerySelectorAll("p");
            classes = nodes.SelectMany(i => i.GetClassList());



            nodes = doc.QuerySelectorAll("H3 + *");
            nodes = doc.QuerySelectorAll("p + p");
            nodes = doc.QuerySelectorAll("p ~ p");

            nodes = doc.QuerySelectorAll("*[data-attr*=1]");
            nodes = doc.QuerySelectorAll("*[data-attr~=11]");


            nodes = doc.QuerySelectorAll("*[class=cls]");
            nodes = doc.QuerySelectorAll("*[class*=cls]");



            node = doc.QuerySelector("p:first-child");
            Console.Write(node.InnerText);
            node = doc.QuerySelector("p:nth-child(3)");
            Console.Write(node.InnerText);


            nodes = doc.QuerySelectorAll("*");
            nodes = doc.QuerySelectorAll("div > p");
            nodes = doc.QuerySelectorAll("p.cls");
      
        }
    }
}

